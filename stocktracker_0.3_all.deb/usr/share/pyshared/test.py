def test1():
    
    from stocktracker.data_provider import DataProvider
    from stocktracker.objects import Stock
    import datetime
    
    d = DataProvider()
        
    s = Stock(12, "GOOG", 'GOOG', 0.0, None, None, None, None, None, None)
    
    date1 = datetime.date(2009, 11, 25)
    date2 = datetime.date(2009, 11, 24)
    dp = DataProvider()
    res = dp.get_historical_prices(s, date1, date2)
    print "return", res
    
    
def test2():
    from stocktracker.dialogs import StockSelector
    from stocktracker import persistent_store, objects, config
    import gtk
   
    store = persistent_store.Store(config.db_file)
    model = objects.Model(store)
    store.model = model
    model.initialize()
    
    win = gtk.Window()
    win.add(StockSelector(model.stocks))
    win.show_all()
    
    gtk.main()    
        
def test3():
    from stocktracker.dialogs import AddStockDialog
    import __builtin__
    __builtin__._ = str
    from stocktracker import persistent_store, objects, config
    import gtk
    configs = config.StocktrackerConfig()
    store = persistent_store.Store(configs.get_option('database file'))
    model = objects.Model(store)
    store.model = model
    model.initialize()

    AddStockDialog(model)
    
    gtk.main()    

def test4():
    from stocktracker.dialogs import AddStockDialog
    import __builtin__
    __builtin__._ = str
    from stocktracker import persistent_store, objects, config
    import gtk
    from datetime import datetime
   
    configs = config.StocktrackerConfig()
    store = persistent_store.Store(configs.get_option('database file'))
    model = objects.Model(store)
    store.model = model
    model.initialize()
    
    date1 = datetime(2009, 12,1)
    #print model.portfolios[1].cash_over_time(date1)
    model.portfolios[11].value_over_time(date1)
        

if __name__ == '__main__':
    test4()
